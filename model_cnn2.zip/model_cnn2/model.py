import torch
import torch.nn as nn
import torch.nn.functional as F


class Model(nn.Module):
    def __init__(self, kernel_size, voc_size, voc_dim):
        super(Model, self).__init__()
        self.channel = voc_dim
        self.embedding = nn.Embedding(voc_size, voc_dim)
        self.cnn = nn.Sequential(nn.Conv1d(voc_dim, voc_dim, kernel_size, bias=False),
                                 nn.ReLU(),
                                 nn.MaxPool1d(2, 2),
                                 nn.Conv1d(voc_dim, voc_dim, kernel_size, bias=False),
                                 nn.ReLU(),
                                 nn.MaxPool1d(2, 2),
                                 nn.Linear(8, 8),
                                 nn.Linear(8, 4),
                                 nn.Linear(4, 1)
                                 )
        self.distance = nn.CosineSimilarity(dim=1)

    def forward(self, input_1, input_2):
        embedded_1 = self.embedding(input_1)
        embedded_2 = self.embedding(input_2)
        input_shape = embedded_1.size()
        cnn_output_1 = self.cnn(embedded_1.view(input_shape[0], input_shape[2], input_shape[1]))
        cnn_output_2 = self.cnn(embedded_2.view(input_shape[0], input_shape[2], input_shape[1]))

        distance = self.distance(cnn_output_1, cnn_output_2)

        output = torch.cat((distance, 1. - distance), dim=1)
        return output

# class Classifier(nn.Module):
#     def __init__(self):
#         super(Classifier, self).__init__()
#         self.distance = nn.CosineSimilarity(dim=1)
#         self.classifier_value = nn.Parameter(torch.tensor(data=0.5, dtype=torch.float))
#
#     def forward(self, hidden_1, hidden_2):
#         sign = self.distance(hidden_1, hidden_2) - self.classifier_value
#
#         return out.view(-1, 1)

# class ContrastiveLoss(torch.nn.Module):
#     """
#     Contrastive loss function.
#     Based on: http://yann.lecun.com/exdb/publis/pdf/hadsell-chopra-lecun-06.pdf
#     """
#
#     def __init__(self, margin=1.0):
#         super(ContrastiveLoss, self).__init__()
#         self.margin = margin
#
#     def forward(self, output1, output2, label):
#         euclidean_distance = F.pairwise_distance(output1.view(1,-1), output2.view(1,-1))
#         loss_contrastive = torch.mean((1-label) * torch.pow(euclidean_distance, 2) +
#                                       (label) * torch.pow(torch.clamp(self.margin - euclidean_distance, min=0.0), 2))
#
#
#         return loss_contrastive
